import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TextInput,
  Button,
  ActivityIndicator,
} from 'react-native';
import axios from 'axios';

export default function App() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const API_URL = 'https://cc22-175-107-227-245.ngrok-free.app/jobs'; // Update if Ngrok URL changes

  // Fetch jobs when logged in
  useEffect(() => {
    if (isLoggedIn) {
      const fetchJobs = async () => {
        setLoading(true);
        try {
          console.log('Fetching jobs from:', API_URL);
          const response = await axios.get(API_URL);
          console.log('Fetched data:', response.data);
          setJobs(response.data);
        } catch (err) {
          console.error('Fetch error:', err.message);
          setError('Failed to load jobs: ' + err.message);
        } finally {
          setLoading(false);
        }
      };
      fetchJobs();
    }
  }, [isLoggedIn]);

  // Handle login
  const handleLogin = () => {
    // Hardcoded credentials for demo (replace with real auth later if needed)
    const validUsername = 'bilal';
    const validPassword = '123';

    if (username === validUsername && password === validPassword) {
      setIsLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Invalid username or password');
    }
  };

  // Render job item
  const renderJob = ({ item }) => (
    <View style={styles.jobContainer}>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.company}>
        {item.company} - {item.location}
      </Text>
      <Text style={styles.description}>{item.description}</Text>
      <Text style={styles.requirements}>
        Requirements: {item.requirements}
      </Text>
      <Text style={styles.applyLink}>Apply: {item.applyLink}</Text>
    </View>
  );

  // Login Screen
  if (!isLoggedIn) {
    return (
      <View style={styles.centered}>
        <Text style={styles.header}>Login</Text>
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        {loginError ? (
          <Text style={styles.error}>{loginError}</Text>
        ) : null}
        <Button title="Login" onPress={handleLogin} />
      </View>
    );
  }

  // Job Listings Screen
  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Loading jobs...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Job Listings</Text>
      {jobs.length === 0 ? (
        <Text style={styles.noJobs}>No jobs available</Text>
      ) : (
        <FlatList
          data={jobs}
          renderItem={renderJob}
          keyExtractor={(item) => item._id || item.title}
          contentContainerStyle={styles.list}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 50,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
  },
  jobContainer: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  company: {
    fontSize: 16,
    color: '#555',
  },
  description: {
    fontSize: 14,
    marginTop: 5,
  },
  requirements: {
    fontSize: 14,
    color: '#777',
    marginTop: 5,
  },
  applyLink: {
    fontSize: 14,
    color: '#0066cc',
    marginTop: 5,
  },
  error: {
    fontSize: 16,
    color: 'red',
    textAlign: 'center',
    marginBottom: 10,
  },
  noJobs: {
    fontSize: 16,
    textAlign: 'center',
  },
  list: {
    paddingBottom: 20,
  },
});